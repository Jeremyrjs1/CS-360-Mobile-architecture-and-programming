package com.zybooks.jeremyrojas_eventtrackingapp;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.jetbrains.annotations.Nullable;

public class HomeActivity extends AppCompatActivity {

    // Define class variables
    FloatingActionButton notify;
    FloatingActionButton add;
    RecyclerView recyclerView;

    // Define database and arrays
    EventDBHelper eventDB;
    ArrayList<String> event_id, event_date, event_description;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize class variables
        notify = (FloatingActionButton) findViewById(R.id.notify);
        add = (FloatingActionButton) findViewById(R.id.addButton);
        recyclerView = (RecyclerView) findViewById(R.id.recycler);


        // Add button clicked
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });

        // Initialize array lists
        eventDB = new EventDBHelper(HomeActivity.this);
        event_id = new ArrayList<>();
        event_date = new ArrayList<>();
        event_description = new ArrayList<>();

        // Call display data function
        displayData();

        // Apply custom adapter for recycler view
        customAdapter = new CustomAdapter(HomeActivity.this, this, event_id, event_date, event_description);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(HomeActivity.this));


        // Notification button clicked
        notify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), NotifyActivity.class);
                startActivity(intent);
            }
        });
    }

    // Refresh activity after update
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1 ){
            recreate();
        }
    }

    // Function to display data
    void displayData() {
        Cursor cursor = eventDB.readData();
        // If database empty
        if(cursor.getCount() == 0) {
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        }
        else{
            // Iterate through database
            while (cursor.moveToNext()){
                event_id.add(cursor.getString(0));
                event_date.add(cursor.getString(1));
                event_description.add(cursor.getString(2));
            }
        }
    }
}
