package com.zybooks.jeremyrojas_eventtrackingapp;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {

    // Define class variables
    EditText eventDate, eventDescription;
    Button buttonUpdate, buttonDelete;
    String id, date, description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        // Initialize class variables
        eventDate = findViewById(R.id.eventDate2);
        eventDescription = findViewById(R.id.eventDescription2);
        buttonUpdate = findViewById(R.id.buttonUpdate);
        buttonDelete = findViewById(R.id.buttonDelete);

        // Call get and set intent method
        getAndSetIntentData();

        // Dynamically set action bar title
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle("Event # " + id);
        }

        // Update button clicked
        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EventDBHelper eventDB = new EventDBHelper(UpdateActivity.this);
                date = eventDate.getText().toString().trim();
                description = eventDescription.getText().toString().trim();
                eventDB.updateData(id, date, description);
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
            }
        });

        // Delete button clicked
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog();
            }
        });
    }

    void getAndSetIntentData() {
        if(getIntent().hasExtra("id") && getIntent().hasExtra("date") &&
                getIntent().hasExtra("description")){

            // Get data from intent
            id = getIntent().getStringExtra("id");
            date = getIntent().getStringExtra("date");
            description = getIntent().getStringExtra("description");

            // Set intent data
            eventDate.setText(date);
            eventDescription.setText(description);
        }
        else {
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        }
    }

    // Alert dialog method to confirm data deletion
    void alertDialog() {
        AlertDialog.Builder  builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete event # " + id +" ?");
        builder.setMessage("Do you want to delete event # " + id + " ?");
        // Set positive button
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                EventDBHelper eventDB = new EventDBHelper(UpdateActivity.this);
                eventDB.deleteData(id);
                finish();
            }
        });
        // Set negative button
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }
}