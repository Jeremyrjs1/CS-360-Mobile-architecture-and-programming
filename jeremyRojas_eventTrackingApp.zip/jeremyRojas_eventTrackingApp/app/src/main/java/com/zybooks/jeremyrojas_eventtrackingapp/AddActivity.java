package com.zybooks.jeremyrojas_eventtrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {

    // Define class variables
    EditText date, description;
    Button add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // Initialize class variables
        date = findViewById(R.id.eventDate);
        description = findViewById(R.id.eventDescription);
        add = findViewById(R.id.buttonAdd);

        // Add button clicked
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EventDBHelper eventDB = new EventDBHelper(AddActivity.this);
                eventDB.addEvent(date.getText().toString().trim(), description.getText().toString().trim());

                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
            }
        });
    }
}