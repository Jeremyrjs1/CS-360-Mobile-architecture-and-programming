package com.zybooks.jeremyrojas_eventtrackingapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    // Define class variables
    private Context context;
    private ArrayList eventID, eventDate, eventDescription;
    Activity activity;


    // Function for assigning array values
    CustomAdapter(Activity activity, Context context, ArrayList eventID, ArrayList eventDate,
                  ArrayList eventDescription) {
        this.activity = activity;
        this.context = context;
        this.eventID = eventID;
        this.eventDate = eventDate;
        this.eventDescription = eventDescription;
    }

    // Create layout inflater
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.event_row, parent, false);
        return new MyViewHolder(view);


    }

    // Bind event data
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.eventID.setText(String.valueOf(eventID.get(position)));
        holder.eventDate.setText(String.valueOf(eventDate.get(position)));
        holder.eventDescription.setText(String.valueOf(eventDescription.get(position)));
        holder.eventLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra("id", String.valueOf(eventID.get(position)));
                intent.putExtra("date", String.valueOf(eventDate.get(position)));
                intent.putExtra("description", String.valueOf(eventDescription.get(position)));

                activity.startActivityForResult(intent, 1);
            }
        });
    }

    // Retrieve event data for recycler view
    @Override
    public int getItemCount() {
        return eventID.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView eventID, eventDate, eventDescription;
        LinearLayout eventLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            eventID = itemView.findViewById(R.id.eventIDText);
            eventDate = itemView.findViewById(R.id.eventDateText);
            eventDescription = itemView.findViewById(R.id.eventDescriptionText);
            eventLayout = itemView.findViewById(R.id.eventLayout);
        }
    }
}
