package com.zybooks.jeremyrojas_eventtrackingapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class NotifyActivity extends AppCompatActivity {

    // Class variables and buttons
    Button notifyYes, notifyNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notify);

        // Initialize buttons
        notifyYes = findViewById(R.id.buttonNotifyYes);
        notifyNo = findViewById(R.id.buttonNotifyNo);


        // Notify yes button clicked
        notifyYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Create notification builder
                NotificationCompat.Builder builder = new NotificationCompat.Builder(NotifyActivity.this,
                "Upcoming Event Notification!");
                builder.setContentTitle("Upcoming Event");
                builder.setContentText("This is an Event Tracker Notification");
                builder.setSmallIcon(R.drawable.notify);
                builder.setAutoCancel(true);

                NotificationManagerCompat  managerCompat = NotificationManagerCompat.from(NotifyActivity.this);
                managerCompat.notify(1, builder.build());

                // Notification channel for newer builder versions
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    NotificationChannel channel = new NotificationChannel("Upcoming Event Notification!",
                            "Event Notification", NotificationManager.IMPORTANCE_DEFAULT);
                    NotificationManager manager = getSystemService(NotificationManager.class);
                    manager.createNotificationChannel(channel);
                }
            }
        });

        notifyNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
            }
        });

    }
}